This directory contains skeleton Deck configuration hydrated by Halyard.

This config is **deprecated** and in general should not be further updated.
To set a default config value, either set the value in `/core/config/settings.ts`
or set a default in the code reading the config property.
