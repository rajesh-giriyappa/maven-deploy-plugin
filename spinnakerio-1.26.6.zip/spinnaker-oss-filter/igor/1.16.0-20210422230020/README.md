This directory contains skeleton igor configs to which Halyard concatenates
its generated deployment-specific config.

These configs are **deprecated** and in general should not be further updated. To
set a default config value, either set the value in `igor-web/config/igor.yml`
or set a default in the code reading the config property.
